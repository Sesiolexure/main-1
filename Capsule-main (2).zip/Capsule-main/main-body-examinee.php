<div id="layoutSidenav_content">
    <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Examinee's List</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Examinee</li>
                        </ol>
                        <div class="row">
                            
                        </div>
                        <!-- Table content -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Data of Examinees
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-danger me-md-2" type="button">Print</button>
                            </div>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Gender</th>
                                            <th>Preffered Course</th>
                                            <th>Cellphone no.</th>
                                            <th>View Result</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Francis Obo</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0949534353</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>Paul Vincent Obsenares</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0910434345</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Hannah Sarah Parallag</td>
                                            <td>Female</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td>Elijah Ken Rebuelta</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>5</td>
                                            <td>Mark Roldan Sedilla</td>
                                            <td>Female</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>6</td>
                                            <td>Rhode Jefferson Tanjutco</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>7</td>
                                            <td>Fernan Rabanes jr</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>8</td>
                                            <td>Lyra Pearl Contreras</td>
                                            <td>Female</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>9</td>
                                            <td>Robert Salas</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>10</td>
                                            <td>Renzy carlo Morte</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>11</td>
                                            <td>John Rin Hofellina</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                        <tr>
                                            <td>12</td>
                                            <td>Paolo Lim</td>
                                            <td>Male</td>
                                            <td>BSIT</td>
                                            <td>0966854331</td>
                                            <td><a href="#" class="href">View</a></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                <main>
                        