<title>ADD QUESTIONS</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
<?php include 'header.php'; ?>
<?php include 'menubar.php'; ?>
<?php include 'sidebar.php'; ?>
<?php include 'main-body-add-question.php'; ?>


</body>
</html>