<div id="layoutSidenav_content">
    <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">ADD QUESTION</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item "><a href="question.php">Subject Question</a></li>
                            <li class="breadcrumb-item active">ADD Question</li>
                        </ol>
                        </ol>
                        <div class="row">
                            
                        </div>
                        <!-- Table content -->
        <Form action="registration.php" method="post">
                
            <div class="row">

                <div class="col-md-6 mb-4 pb-2">

                    <div class="form-outline">
                        <input type="text" id="questionno" class="form-control form-control-lg" name="questionno" />
                            <label class="form-label" for="questionno">No.</label>
                    </div>

                </div>

            

                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <input type="text" id="subject" class="form-control form-control-lg" name= "subject"/>
                    <label class="form-label" for="subject">Subject</label>
                  </div>
                </div>  

            </div>

            <div class="row">
                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <input type="text" id="question" class="form-control form-control-lg" name = "question" />
                    <label class="form-label" for="question">Question</label>
                  </div>

                </div>
            

           
                <div class="col-md-6 mb-4 d-flex align-items-center">

                  <div class="form-outline datepicker w-100">
                    <input type="text" class="form-control form-control-lg" id="answer" name="answer" />
                    <label for="answer" class="form-label">Answer</label>
                  </div>

                </div>
              
            </div>


                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="question.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true"> ADD  </a>
                                <a href="question.php" class="btn btn-danger" tabindex="-1" role="button" aria-disabled="true"> Cancel </a>
                            </div>

                            <div class="row">
                            </div>
            </form>
            

                    </div>
                <main>
                        