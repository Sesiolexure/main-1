<?php
include('conn.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style1.css">
</head>
<body>
    
<div class="low-bg-image">
</div>
    <div class="container">
        
            <h1><b>Registration<b></h1>
        
            <?php 
        if(isset($_GET['id'])){
          $firstname = $_POST['exm_fname'];
          $lastname = $_POST['exm_lname'];
          $birthdate = $_POST['exm_bdate'];
          $emailadd = $_POST['email'];
          $phonenumber = $_POST['cnum'];
          $gender = $_POST['exm_gender'];
          $course = $_POST['pref_course'];
      
          $query = $conn->prepare("INSERT INTO `examinee_db` (`exm_fname`,`exm_lname`,`exm_bdate`,`email`,`exm_address`,`exm_gender`,`pref_course`)VALUES (null,:exm_fname, :exm_lname)");
          if($query){
              echo "<script>alert('data inserted successfully')</script>";
          }   else {
              echo "<script>alert('there is an error')</script>";
          }
          
      } 
        ?>
            <Form action="registration.php" method="post">
                
              <div class="row">
                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <input type="text" id="firstName" class="form-control form-control-lg" name= "firstname"/>
                    <label class="form-label" for="firstName">First Name</label>
                  </div>

                </div>
                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <input type="text" id="lastName" class="form-control form-control-lg" name = "lastname" />
                    <label class="form-label" for="lastName">Last Name</label>
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center">

                  <div class="form-outline datepicker w-100">
                    <input type="text" class="form-control form-control-lg" id="birthdayDate" name="birthdate" />
                    <label for="birthdayDate" class="form-label">Birthday</label>
                  </div>

                </div>
                <div class="col-6">

                <select class="gender" id="gender" aria-label="Default select example" name="gender">
                    <option selected>Gender</option>
                    <option value="1">Male</option>
                    <option value="2">Female</option>
                </select>


                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 pb-2">

                  <div class="form-outline">
                    <input type="email" id="emailAddress" class="form-control form-control-lg" name="emailadd" />
                    <label class="form-label" for="emailAddress">Email</label>
                  </div>

                </div>
                <div class="col-md-6 mb-4 pb-2">

                  <div class="form-outline">
                    <input type="tel" id="phoneNumber" class="form-control form-control-lg" name="phonenumber" />
                    <label class="form-label" for="phoneNumber">Phone Number</label>
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-12">

                  <select class="select form-control-lg" name = "course">
                    <option value="1" disabled>Preffered Course</option>
                    <option value="2">BSIT</option>
                    <option value="3">BSHM</option>
                    <option value="4">BSTM</option>
                  </select>
                  <label class="form-label select-label">Preffered Course</label>

                </div>
              </div>

              <div class="mt-4 pt-2">
                <input class="btn btn-primary btn-lg" type="submit" value="Register" name="submit" />
              </div><label class="form-label select-label">for examineer</label>
              <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                                <button href="capsule-main/index.php" class="btn btn-danger me-md-2" type="button">Log-in As ADMIN</button>
              </div>

            </form>
    
    </div>
    <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Team Malupets </div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
</body>
</html>