<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSTA Entrance Examination</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel = "stylesheet" href = "pop-up.css">
</head>
<body>
    <div class="low-bg-image">
    </div>

        <div class="container">
        
            <div class="imgcontainer">
                <img src="images/logos.png" alt="avatar" class="img">
            </div>
    
                <h1><b> Colegio De Sta. Teresa De Avila </b></h1>
                        <h1> Entrance Examination </h1>

                        <a href="#" class="button" id="button">Sign-up</a>
                                <strong>or<strong>
                        <a href="#" class="button" id="admin">Sign-in as Admin</a>
        </div>
        <div class="register-form">
            <label for="show" class="close-btn fas fa-times" title="close"></label>
            <div class="text">
               Login Form
            </div>
            <form action="#">
               <div class="data">
                  <label>Email or Phone</label>
                  <input type="text" required>
               </div>
               <div class="data">
                  <label>Password</label>
                  <input type="password" required>
               </div>
               <div class="forgot-pass">
                  <a href="#">Forgot Password?</a>
               </div>
               <div class="btn">
                  <div class="inner"></div>
                  <button type="submit">login</button>
               </div>
               <div class="signup-link">
                  Not a member? <a href="#">Signup now</a>
               </div>
            </form>
        
        </div>
                    

                    
</body>
</html>