<div id="layoutSidenav_content">
    <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">ADMIN INFORMATION</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                            <li class="breadcrumb-item active">Admin Settings</li>
                        </ol>
                        <div class="row">
                            
                        </div>
                        <!-- Table content -->
                        <div class="card mb-4">
                            <div class="card-header">
                                
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-danger me-md-2" type="button">ADD Admin</button>
                            </div>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th colspan="5" class="table-active">ADMIN USERNAME</th>
                                            <th>PASSWORD</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colspan="5" class="table-active">ADMIN</td>
                                            <td colspan="5" class="table-active">cg456754675bb63nu85474g75</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">EDIT</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td colspan="5" class="table-active">TEACHERS</td>
                                            <td colspan="5" class="table-active">li75gb43bh75bg7896425444gh</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">EDIT</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td colspan="5" class="table-active">GUIDANCE</td>
                                            <td colspan="5" class="table-active">dw234kg54354kg08589223n4j5</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">EDIT</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                <main>
                        