<?php include 'header.php'; ?>
<?php include 'menubar.php'; ?>
<?php include 'sidebar.php'; ?>
<?php include 'main-body.php'; ?>
<?php include 'footer.php'; ?>

</body>
</html>